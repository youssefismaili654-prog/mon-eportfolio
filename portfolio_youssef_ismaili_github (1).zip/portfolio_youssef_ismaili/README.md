# Portfolio de Youssef Ismaili

Site statique HTML/CSS/JavaScript prêt pour GitHub Pages.

## Mise à jour du dépôt
1. Décompresser l'archive.
2. Ouvrir le dépôt GitHub `mon-eportfolio`.
3. Remplacer les fichiers `index.html`, `style.css` et `script.js` à la racine.
4. Cliquer sur **Commit changes**.
5. Attendre le déploiement GitHub Pages.

## À compléter
- Ajouter une photo personnelle à la place du bloc `photo` dans `index.html`.
- Remplacer `TON.ADRESSE@EXEMPLE.COM` par ton adresse e-mail.
- Ajouter ton CV dans `documents/CV_Youssef_Ismaili.pdf`.
- Détailler le sujet et les résultats de ton TIPE, tes projets C/Python/MATLAB et tes centres d'intérêt.
