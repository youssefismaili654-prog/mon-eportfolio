# e-Portfolio étudiant ingénieur

## Lancer le site
1. Décompressez le dossier.
2. Ouvrez `index.html` dans votre navigateur.
3. Pour le publier, déposez les fichiers sur un dépôt GitHub puis activez GitHub Pages dans Settings > Pages.

## Personnalisation rapide
- Remplacez les textes d'exemple dans `index.html`.
- Remplacez le bloc `.portrait-placeholder` par une vraie photo (balise `<img>`).
- Modifiez les liens e-mail, LinkedIn et CV.
- Placez votre CV PDF dans `assets/` et nommez-le `cv-exemple.pdf` (ou changez le lien dans le HTML).
- Les couleurs et styles se modifient dans `style.css`.

Cette première version est un modèle statique autonome : HTML, CSS et JavaScript, sans framework ni installation.
